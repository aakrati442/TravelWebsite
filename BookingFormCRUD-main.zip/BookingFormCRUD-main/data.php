<?php
$bname= $_POST['bname'];
$dname=$_POST['dname'];
$qty=$_POST['qty'];
$Price=$_POST['Price'];


?>